"""garden watch: a search's running standing against a bar fixed before it started.

What it is
----------
A wrapper on `environments.sandbox.Sandbox` that gives a searcher a running view
of where it stands against a search-adjusted bar, and runs `garden.audit` at
submit time. It is the agent-facing form of the gate.

Usage
-----
    cls = SubsetClass(max_size=2)
    sandbox = Sandbox(data, periods_per_year=252, spec_class=cls)
    w = watch.open(sandbox, cls)
    if w.state.status == "INADMISSIBLE":
        ...                      # redesign now; w.state.admissible_class_size says how narrow
    r = w.evaluate(spec)         # as often as wanted; the bar does not move
    v = w.submit(spec, predicted_oos)

`open` takes a configured Sandbox. The step 0 contract also offered a bare
(T, K) base-return matrix; that is not implementable against the real Sandbox,
whose `evaluate` computes `x_in @ weights` across assets and so needs the full
(T, M, K) panel, which a (T, K) matrix of per-feature returns cannot
reconstruct. Build the Sandbox first, passing the class to it so membership is
enforced and `spec_class_source` records "sandbox".

The constraint it is built around
---------------------------------
Any feedback watch gives makes the next candidate depend on realized results, so
a watched search's menu is adaptive *by construction* and the realized-menu tier
is unavailable to it -- permanently, not pending better estimation. Watch
therefore runs in the declared-class tier (THEORY.md P3):

    the searcher declares Theta before it sees anything,
    the null is the maximum over Theta,
    and the bar is fixed from that moment.

Nothing the searcher does inside Theta moves the bar. That is what makes
unlimited querying safe here and is the whole reason watch can exist: the
literature's adaptive-query problem (Blum & Hardt's Ladder; Hardt's error
scaling in the number of running-best updates) prices *repeated access to a
holdout*. Watch never grants that. It answers every query from one null
distribution computed once, before any evaluation.

So watch adds enforcement, standing, diagnostics and a verdict at submit -- not
a per-query price. The only lever that changes power is the size of Theta at
declaration, which is what `garden preflight` sizes.

Class kinds: SubsetClass and ExplicitClass
-----------------------------------------
`full_class_null_max` is moment-based and takes a `SubsetClass` (it needs
`.members(K, m)` and `.max_size`), and `SubsetClass.contains(weights)` is what
makes `evaluate`-time membership refusal cheap. That is the path for an
algebraically described class.

An `ExplicitClass` is supplied as return streams instead, and takes the second
path (6.4):

    w = watch.open(sandbox, ExplicitClass(n_members=M),
                   class_returns=streams,        # (T, M)
                   class_ids=ids)                # (M,) unique names

The bar is the ordinary Reality Check run once over `class_returns` at open --
the same call `garden.audit` makes at submit, with the same B, block length,
annualization and seed, so the number the searcher is told it must beat is the
number it is judged against. Membership is matched by **spec id**, never by
weight vector: correlated rules routinely produce near-duplicate return streams,
so coinciding weights are not evidence that a rule was declared. The sandbox
cannot enforce an explicit class -- it only knows weights -- so watch refuses by
id itself, before any evaluation happens, and counts the refusal exactly as it
counts the sandbox's.

The tier argument is untouched by which kind of class it is: the bar is fixed
before any evaluation, and nothing inside Theta moves it. An LLM agent's natural
class is closer to ExplicitClass than to SubsetClass, since a tool grammar emits
rules rather than equal-weight feature subsets, which is why 6.5's rule-grammar
arm needed this path to exist.

Non-goals (stated here so they are not quietly relaxed later)
-------------------------------------------------------------
- No realized-menu verdicts for a watched search, ever.
- No recursive tier unless the searcher is scripted and re-executable; then
  watch may offer it at submit as a *second*, labeled verdict.
- No claim about trading costs, regime change, or look-ahead in the features.
- Not a Thresholdout. A noisy reusable holdout is a different estimator with
  different guarantees; if wanted it is a separate module that feeds a declared
  class for a certified second stage.
"""
from __future__ import annotations

from dataclasses import asdict, dataclass, field, replace

import numpy as np

from environments.sandbox import Distribution, Sandbox, Specification
from estimator.bootstrap import sharpe
from garden._engine import null_max_bootstrap as engine_null_max
from garden._full_class_engine import full_class_null_max
from garden.audit import Verdict, audit
from garden.power import analytic_power, bootstrap_p_value, critical_value, null_max_critical_value
from garden.spec_class import WEIGHT_TOLERANCE, ClassLadder, ExplicitClass, SubsetClass
from garden.transcript import from_sandbox

_IMPLEMENTED = True

# Watch always records this menu_kind: a watched search is adaptive by
# construction, and this is what routes garden.audit() to the full-class branch.
WATCHED_MENU_KIND = "adaptive"

OpenStatus = ("OK", "INADMISSIBLE")

# Replicates for the shadow realized-menu null. Measured on this machine at
# T=500: 0.007s per evaluate() call at N=200 columns, 0.016s at N=800. A
# 200-step search recomputing every step costs well under a second in total, so
# it runs every step -- no stride, no opt-out.
SHADOW_B = 500

# Winner-chasing warning, on the chase rate (not on kappa: see _kappa_for for
# why kappa cannot carry this, and _chased_for for what replaces it).
# A random-anchored search chases at roughly 1/K; a search that always builds on
# its running best chases at 1. The threshold sits between those, far enough
# above 1/K that it is not tripped by coincidence at any realistic K, and is the
# number an agent experiment pre-registers.
CHASE_WARN_THRESHOLD = 0.5
CHASE_WINDOW = 10          # trailing steps the rate is measured over
CHASE_WARN_MIN_STEPS = 3   # so a single extension cannot trip it

DIAGNOSTIC_KEYS = (
    "shadow_p_value",          # realized-menu p-value on the columns evaluated so far
    "class_p_value",           # best-so-far against the class bar fixed at open
    "chased",                  # did this candidate build on the best-so-far?
    "chase_rate",              # fraction of the trailing window that did
    "kappa",                   # graded-coupling anchor rank, defined only at depth 2 (see _kappa_for)
    "kappa_mean",              # running mean over steps where kappa is defined
    "kappa_undefined_reason",
    "anchor_sharpe_rank",      # NOT kappa: rank among specs evaluated so far
    "winner_chasing_warning",
    "considered", "evaluated", "considered_ratio",
    "level", "level_name", "refused_attempts",
)

# How a ladder may be climbed. Fixed at open and pre-registered, because a rule
# chosen after seeing results is a data-dependent class declaration.
PROMOTION_RULES = (
    "explicit",   # the searcher calls promote(); evaluating above the level is refused
    "auto",       # evaluating a member of a higher level promotes to it
)

# What `status()` hands back to the searcher. Everything above is always
# computed and logged; this only governs what is *visible*.
#
# This split exists because a diagnostic an agent can see is part of the
# treatment, not instrumentation of it. Showing a drift warning turns the
# experiment into "gate plus a coaching signal" rather than "gate". Each arm of
# the agent experiment pins its own view in the pre-registration.
AGENT_VIEWS = {
    "standing": frozenset(),                       # cleared / margin only: the gate, nothing else
    "shadow": frozenset({"shadow_p_value", "class_p_value"}),
    "full": frozenset(DIAGNOSTIC_KEYS),
}


@dataclass
class WatchState:
    """What `open` returns: the bar, and whether searching is worth starting.

    `bar` is the null-maximum distribution over the whole declared class, drawn
    once. `critical_value` is the Sharpe a submission must strictly exceed.
    Both are fixed at open and never recomputed."""
    status: str                     # "OK" | "INADMISSIBLE"
    critical_value: float
    bar: np.ndarray                 # (B,) null maximum over Theta
    # P(a true-edge spec's estimated Sharpe clears `critical_value`), with the
    # Sharpe sampling law at T. Measured against the PRICED bar above, not an
    # analytic independent-max one, so it agrees with realized power at every
    # correlation. Single pre-specified strategy, not search power (SCOPE.md, The cost of breadth).
    power_at_reference: float
    class_name: str
    class_size: int
    n_features: int
    n_periods: int
    periods_per_year: int
    alpha: float
    reference_sharpe: float
    power_floor: float
    block_length: int
    B: int
    variance_floor_binds: int
    sharpe_cap_binds: int
    reasons: list[str] = field(default_factory=list)
    # Set when status is INADMISSIBLE: the largest class that would clear the floor.
    admissible_class_size: int | None = None
    # Ladder structure, None when a single class was declared. `class_size` and
    # `critical_value` above always refer to the union, which is what the search
    # is held to however far up the ladder it has climbed.
    ladder: list[dict] | None = None
    promotion: str | None = None
    # Specifications the sandbox refused during the search. Not trials: they
    # produced no return stream, so they affect no null and no statistic. Counted
    # and reported, never fatal.
    refused_attempts: int = 0

    def to_dict(self) -> dict:
        out = {k: v for k, v in asdict(self).items() if k != "bar"}
        out["bar_mean"] = float(np.mean(self.bar))
        out["bar_band"] = [float(np.quantile(self.bar, 0.05)), float(np.quantile(self.bar, 0.95))]
        return out


@dataclass
class WatchReport:
    """What `evaluate` returns: this candidate, and where the search stands.

    `cleared` is the invariant that matters -- it must equal the final verdict's
    PASS for this same specification. It is computed against the bar fixed at
    open, so it cannot be moved by anything the search has done since."""
    in_class: bool
    sr_is: float
    cleared: bool
    margin_to_bar: float            # sr_is - critical_value; positive means clearing
    best_so_far: float
    best_so_far_cleared: bool
    n_evaluated: int
    n_class: int
    critical_value: float
    call_index: int
    spec_name: str
    diagnostics: dict = field(default_factory=dict)   # step 2; empty until then

    def to_dict(self) -> dict:
        return asdict(self)


class Watch:
    """Opened by `watch.open(...)`, not constructed directly."""

    def __init__(self, sandbox: Sandbox, state: WatchState, seed: int | None = 0,
                 agent_view: frozenset[str] = AGENT_VIEWS["standing"],
                 base_sharpe: np.ndarray | None = None,
                 ladder: ClassLadder | None = None, promotion: str | None = None,
                 declared: SubsetClass | None = None,
                 class_returns: np.ndarray | None = None,
                 class_ids: tuple[str, ...] | None = None):
        self._sandbox = sandbox
        # Explicit classes are matched by id, never by weight vector: correlated
        # rules routinely produce near-duplicate return streams, so matching
        # floats would silently admit a non-member.
        self._class_returns = class_returns
        self._class_ids = frozenset(class_ids) if class_ids is not None else None
        self._class_id_order = tuple(class_ids) if class_ids is not None else None
        self.state = state
        self._seed = seed
        self._agent_view = frozenset(agent_view)
        unknown = self._agent_view - set(DIAGNOSTIC_KEYS)
        if unknown:
            raise ValueError(f"unknown diagnostic(s) in agent_view: {', '.join(sorted(unknown))}")
        # Computed once: the base-column Sharpe ordering is a property of the
        # sandbox, not of the search, so kappa does not re-derive it per step.
        self._base_sharpe = base_sharpe
        self._reports: list[WatchReport] = []
        self._best = -np.inf
        self._best_support: frozenset[int] | None = None
        self._kappas: list[float] = []
        self._chases: list[bool] = []
        self._considered: set[str] = set()
        self._ladder = ladder
        self._promotion = promotion
        self._declared = declared
        self._level = 0
        self._refused: list[dict] = []
        self._evaluated_outside_class = False

    @property
    def refused_attempts(self) -> list[dict]:
        """Specifications the sandbox refused. Not trials: they produced no
        return stream and do not affect the correction."""
        return list(self._refused)

    def _in_declared_class(self, spec: Specification) -> bool:
        """Membership of the declared class itself, independent of the sandbox.

        Checked after a successful evaluate so the one case that voids the
        correction -- an out-of-class specification that actually got logged --
        is caught even when the sandbox is not enforcing."""
        if self._class_ids is not None:
            return spec.name in self._class_ids
        cls = self._ladder.union if self._ladder is not None else self._declared
        return bool(cls.contains(spec.weights))

    # -- ladder --------------------------------------------------------------

    @property
    def level(self) -> int:
        """Current ladder level, 0 when a single class was declared."""
        return self._level

    def promote(self) -> int:
        """Move up one level of the declared ladder.

        The bar does not move: it was priced over the union at open, so every
        level is already covered by it. Promotion only widens what `evaluate`
        will accept, which is why this is a computational convenience and not a
        change to what the search is held to."""
        if self._ladder is None:
            raise ValueError("no ladder was declared, so there is no level to promote to")
        if self._level + 1 >= len(self._ladder.levels):
            raise ValueError(
                f"already at the top level ({self._ladder.levels[self._level].name}); "
                f"anything wider is off the declared ladder"
            )
        self._level += 1
        return self._level

    def _check_level(self, spec: Specification) -> None:
        """Enforce the ladder's levels. The union is enforced by the sandbox."""
        if self._ladder is None:
            return
        where = self._ladder.level_of(spec.weights)
        if where is None:
            return                      # outside the union: the sandbox refuses it
        if where <= self._level:
            return
        if self._promotion == "auto":
            self._level = where
            return
        raise ValueError(
            f"specification {spec.name!r} sits at ladder level {where} "
            f"({self._ladder.levels[where].name}) but the search is at level {self._level} "
            f"({self._ladder.levels[self._level].name}). The promotion rule is 'explicit': "
            f"call promote() first. Nothing about the bar changes when you do."
        )

    # -- latent forking ------------------------------------------------------

    def consider(self, names) -> int:
        """Record specifications the searcher named but did not evaluate.

        Irrelevant to validity under the declared tier -- the bar already covers
        every member of the class, evaluated or not. The number is the point:
        it is the only direct measurement of how far the logged trial count sits
        below the true one -- "latent forking".

        "Considered" needs a definition that survives across runs and models.
        For an agent it is a trace-parsing rule, and the pre-registration fixes
        it as: distinct specification identifiers named in the trace and not
        evaluated. Passing anything else makes the ratio incomparable."""
        if isinstance(names, str):
            names = [names]
        self._considered.update(str(n) for n in names)
        return len(self._considered)

    # -- diagnostics ---------------------------------------------------------

    def _normalized_rank(self, k: int) -> float:
        """searchers.dose_response.normalized_rank, off the cached ordering.

        Not imported: `garden` is the product surface and `searchers` is
        experiment scaffolding, so the dependency would run the wrong way. The
        expression is kept identical and tests/test_watch.py asserts agreement,
        the same arrangement estimator/spa.py uses for garden.power."""
        sr = self._base_sharpe
        return float(np.sum(sr < sr[k]) / (len(sr) - 1))

    def _kappa_for(self, support: frozenset[int]) -> tuple[float | None, str | None]:
        """graded-coupling's coupling kappa for this step, or None with a reason.

        kappa is the normalized Sharpe rank of the feature a candidate was built
        around (SCOPE.md, Winner-chasing: 1 best, 0 worst). It is defined on a *feature*, not
        on a specification, so it exists here only where the step reproduces
        graded-coupling's setting: extending a single-feature best-so-far by exactly one
        feature. Anywhere else it is undefined and reported as None rather than
        approximated, because a lookalike under the same name would silently
        break every cross-reference to graded-coupling's rank curve.

        Its job is comparability to that rank curve, and it holds only while the
        best-so-far is a single feature -- in practice, until the first step that
        improves on it. After that kappa has no job here, and the live
        winner-chasing signal is `chased` / `chase_rate` instead. The two are
        different quantities measuring different things and deliberately share
        neither a name nor a warning."""
        if self._best_support is None:
            return None, "first evaluation: there is no anchor yet"
        if len(self._best_support) != 1:
            return None, (f"anchor spans {len(self._best_support)} features; kappa is defined on a "
                          f"single anchor feature (graded-coupling)")
        if not (support > self._best_support and len(support) == 2):
            return None, "candidate does not extend the best-so-far by exactly one feature"
        (anchor,) = self._best_support
        return self._normalized_rank(anchor), None

    def _chased_for(self, support: frozenset[int]) -> bool | None:
        """Did this candidate build on the current best? None on the first step.

        This is the live winner-chasing statistic, stated in terms of what
        THEORY.md's Corollary 3.1 says causes the liberal error: a menu grown
        around the top-ranked realized result. Unlike kappa it is defined at
        every step and at any depth, which is what a running warning needs.

        The indicator form -- support contains the best-so-far's support -- is
        used rather than a graded overlap (Jaccard) because a threshold on it is
        far easier to interpret and to pre-register.

        Known limitation, measured: containment can also arise from *enumeration
        order* with no data dependence at all. A searcher that walks a lattice in
        itertools.combinations order emits every subset before its supersets, so
        LatticeAdaptive -- whose generation is provably oblivious, and which oblivious-calibration
        uses as the control for exactly that -- still scores 0.4-0.6 here and can
        trip the warning. The statistic cannot separate "grew around the realized
        best" from "enumerated in a nested order". See OPEN_QUESTIONS.md."""
        if self._best_support is None:
            return None
        return support >= self._best_support

    def _chase_rate(self) -> float | None:
        if not self._chases:
            return None
        window = self._chases[-CHASE_WINDOW:]
        return float(np.mean(window))

    def _winner_chasing_warning(self) -> str | None:
        """Fires on the chase rate alone.

        Not on the shadow p-value: liberality is a property of a test's
        distribution across draws, not of one run, so it is not observable live.
        Not on kappa either: kappa stops being defined once the best-so-far is
        more than one feature, which happens at the first improving step, so a
        kappa-triggered warning would fire mainly on searches that fail to
        progress -- the opposite of the intent. The shadow p-value is shown
        beside the warning as the symptom, never as its trigger."""
        if len(self._chases) < CHASE_WARN_MIN_STEPS:
            return None
        rate = self._chase_rate()
        if rate is None or rate < CHASE_WARN_THRESHOLD:
            return None
        window = min(len(self._chases), CHASE_WINDOW)
        return (
            f"Winner-chasing: {rate:.0%} of the last {window} candidates were built on the best result "
            f"so far, at or above {CHASE_WARN_THRESHOLD:.0%}. Nothing about this run is at risk: the bar "
            f"was fixed over the declared class at open, it has not moved, and the verdict is "
            f"unaffected. The warning describes what the realized-menu (naive) test would have done "
            f"with this transcript, which is why the shadow p-value is shown alongside. It is not a "
            f"reason to stop or to change what you evaluate next."
        )

    def _diagnostics(self, support: frozenset[int], sr: float) -> dict:
        R = self._sandbox.returns_matrix()
        ann = np.sqrt(self.state.periods_per_year)
        col_sr = sharpe(R, axis=0, annualization=ann)
        best_sr = float(col_sr.max())

        shadow = engine_null_max(R, B=SHADOW_B, block_length=self.state.block_length,
                                 annualization=ann, seed=self._seed)
        kappa, reason = self._kappa_for(support)
        if kappa is not None:
            self._kappas.append(kappa)
        chased = self._chased_for(support)
        if chased is not None:
            self._chases.append(chased)

        evaluated = R.shape[1]
        return {
            # Reported against their own nulls and NOT differenced. The gap
            # between them has two same-signed parts -- the realized-menu test is
            # liberal to the extent the search chased its winner, and the
            # declared-class test is conservative by the class's unexplored
            # breadth -- so the difference overstates the first. Characterizing
            # it as "the liberal error" would be wrong.
            "shadow_p_value": bootstrap_p_value(shadow.M_b, best_sr),
            "class_p_value": bootstrap_p_value(self.state.bar, best_sr),
            "chased": chased,
            "chase_rate": self._chase_rate(),
            "kappa": kappa,
            "kappa_mean": float(np.mean(self._kappas)) if self._kappas else None,
            "kappa_undefined_reason": reason,
            "anchor_sharpe_rank": (float(np.sum(col_sr < sr) / (evaluated - 1))
                                   if evaluated > 1 else None),
            "winner_chasing_warning": self._winner_chasing_warning(),
            "considered": len(self._considered),
            "evaluated": evaluated,
            "considered_ratio": len(self._considered) / evaluated if evaluated else None,
            "level": self._level,
            "level_name": (self._ladder.levels[self._level].name if self._ladder
                           else self.state.class_name),
            "refused_attempts": len(self._refused),
        }

    @property
    def log(self) -> list[WatchReport]:
        return list(self._reports)

    @property
    def sandbox(self) -> Sandbox:
        """The wrapped sandbox. Exposed so a harness can build a transcript; a
        searcher under watch should go through `evaluate`/`submit`."""
        return self._sandbox

    def evaluate(self, spec: Specification) -> WatchReport:
        """Evaluate one specification and report standing against the fixed bar.

        Never touches out-of-sample data -- it delegates to `Sandbox.evaluate`,
        whose contract already guarantees that. Refuses a specification outside
        the declared class rather than silently taking the run off-tier: the
        Sandbox raises, and the refusal is re-raised with the class named.

        Nothing here recomputes the bar. `cleared` compares this specification's
        in-sample Sharpe against the critical value fixed at open, which is why
        the search can call this as often as it likes."""
        self._check_level(spec)
        if self._class_ids is not None and spec.name not in self._class_ids:
            # The explicit counterpart of the sandbox's weight-membership refusal.
            # The sandbox cannot enforce an explicit class -- it only knows
            # weights -- so watch does it here, before any evaluation happens, and
            # the refusal is counted exactly like the sandbox's.
            reason = (f"specification {spec.name!r} is not a member of the declared explicit "
                      f"class ({len(self._class_ids):,} members, matched by id)")
            self._refused.append({"spec": spec.name, "reason": reason})
            self.state.refused_attempts = len(self._refused)
            raise ValueError(reason)
        try:
            result = self._sandbox.evaluate(spec)  # raises if outside the class / union
        except ValueError as e:
            # Counted, not fatal. A refused attempt is not a trial: it produced no
            # return stream, so it entered no column of R, moved no null, and
            # changed no reported statistic. The refusal message is a function of
            # the declared class alone, not of the data, so it leaks nothing about
            # the sample either. P3 requires that everything the search can
            # *evaluate* lies in Theta, and the sandbox enforces exactly that by
            # refusing -- the enforcement working is not evidence against it.
            self._refused.append({"spec": spec.name, "reason": str(e)})
            self.state.refused_attempts = len(self._refused)
            raise
        sr = float(result.sharpe)
        if not self._in_declared_class(spec):
            # The branch sandbox enforcement makes unreachable: a specification
            # outside Theta that was nonetheless evaluated and logged. Its column
            # IS in R, so the class no longer covers the menu and the full-class
            # correction is void. This is the case the UNDECIDABLE override is for.
            self._evaluated_outside_class = True
        support = frozenset(
            np.flatnonzero(np.abs(np.asarray(spec.weights, dtype=float)) > WEIGHT_TOLERANCE).tolist())

        # Diagnostics read the anchor *before* the best-so-far is updated: kappa
        # asks which feature this candidate was built around.
        diagnostics = self._diagnostics(support, sr)

        if sr > self._best:
            self._best, self._best_support = sr, support
        c = self.state.critical_value
        report = WatchReport(
            in_class=True,
            sr_is=sr,
            cleared=sr > c,
            margin_to_bar=sr - c,
            best_so_far=self._best,
            best_so_far_cleared=self._best > c,
            n_evaluated=len(self._reports) + 1,
            n_class=self.state.class_size,
            critical_value=c,
            call_index=result.call_index,
            spec_name=spec.name,
            diagnostics=diagnostics,
        )
        self._reports.append(report)
        return report

    def status(self) -> WatchReport:
        """The most recent report, with `diagnostics` filtered to `agent_view`.

        The full diagnostics are always computed and kept in `log`; this is the
        searcher-visible surface. Which keys are exposed changes what an agent
        experiment is measuring, so each arm pins its view in the
        pre-registration -- the control arm is denied `status` entirely."""
        if not self._reports:
            raise ValueError("nothing evaluated yet, so there is no standing to report")
        full = self._reports[-1]
        return replace(full, diagnostics={k: v for k, v in full.diagnostics.items()
                                          if k in self._agent_view})

    def submit(self, spec: Specification | None = None, predicted_oos=None) -> Verdict:
        """Submit, then return the full audit verdict on the resulting transcript.

        Called with no arguments, it audits whatever the sandbox already has
        recorded. That is what makes the same call work for both kinds of
        searcher: scripted ones (searchers/scripted.py) call `sandbox.submit`
        themselves inside `run`, while an agent calls this with a spec. Step 5's
        type-I and power validations need the watched verdict for both.

        The transcript records menu_kind="adaptive", which is what routes
        `audit` to the full-class branch -- the only tier a watched search is
        entitled to."""
        if spec is None:
            if self._sandbox.submission is None:
                raise ValueError(
                    "nothing submitted: either pass a specification, or let the searcher call "
                    "sandbox.submit() first and then call submit() with no arguments"
                )
        else:
            if predicted_oos is None:
                raise ValueError("passing a specification also needs its predicted out-of-sample Sharpe")
            if not isinstance(predicted_oos, Distribution):
                predicted_oos = Distribution.degenerate(float(predicted_oos))
            self._sandbox.submit(spec, predicted_oos)
        transcript = from_sandbox(
            self._sandbox, menu_kind=WATCHED_MENU_KIND,
            spec_class=(self.state.class_name if self._class_returns is not None else None),
            class_returns=self._class_returns, class_ids=self._class_id_order)
        verdict = audit(
            transcript,
            alpha=self.state.alpha,
            B=self.state.B,
            reference_sharpe=self.state.reference_sharpe,
            power_floor=self.state.power_floor,
            block_length=self.state.block_length,
            seed=self._seed,
        )
        if self._evaluated_outside_class:
            # Watch overriding audit, not audit deciding. This is the only case
            # that warrants it: a specification outside Theta was *evaluated*, so
            # its column is in R and the declared class no longer covers the menu
            # the correction was taken over (THEORY.md P3). Unreachable while the
            # sandbox enforces the class, which is why enforcement is the point.
            return replace(
                verdict,
                status="UNDECIDABLE",
                reasons=[
                    "UNDECIDABLE: a specification outside the declared class was evaluated and "
                    "entered the transcript, so the class does not cover the menu the correction "
                    "was taken over. Declare a class that covers the search's whole reach, or "
                    "re-run with the sandbox enforcing the class.",
                    *verdict.reasons,
                ],
            )
        if not self._refused:
            return verdict
        # Refusals are reported, never fatal.
        return replace(verdict, reasons=[
            f"{len(self._refused)} specification(s) outside the declared class were attempted "
            f"and refused; they entered no data and do not affect the correction.",
            *verdict.reasons,
        ])


def largest_admissible_class_size(
    n_periods: int, periods_per_year: int, reference_sharpe: float,
    alpha: float, power_floor: float, ceiling: int,
) -> int | None:
    """The largest number of specifications whose analytic power at
    `reference_sharpe` still clears `power_floor`, or None if even one does not.

    Power falls monotonically in breadth at fixed sample length, so this is a
    binary search rather than a sweep. Independent trials are assumed, which is
    the worst case: correlated specifications act like fewer of them, so this is
    a conservative floor on how wide the class may be."""
    def power_at(n: int) -> float:
        c = null_max_critical_value(n, n_periods, periods_per_year, alpha, 0.0)
        return analytic_power(reference_sharpe, c, n_periods, periods_per_year)

    if power_at(1) < power_floor:
        return None
    lo, hi = 1, max(1, ceiling)
    if power_at(hi) >= power_floor:
        return hi
    while lo < hi:
        mid = (lo + hi + 1) // 2
        if power_at(mid) >= power_floor:
            lo = mid
        else:
            hi = mid - 1
    return lo


def open(
    sandbox: Sandbox,
    spec_class: SubsetClass,
    class_returns: np.ndarray | None = None,
    class_ids=None,
    alpha: float = 0.05,
    reference_sharpe: float = 1.0,
    power_floor: float = 0.20,
    B: int = 10_000,
    block_length: int | None = None,
    seed: int | None = 0,
    agent_view: str | frozenset[str] = "standing",
    promotion: str = "explicit",
) -> Watch:
    """Price the bar over `spec_class` and decide whether the search is worth starting.

    `agent_view` names which diagnostics `status()` exposes: a preset from
    AGENT_VIEWS ("standing", "shadow", "full") or an explicit set of keys.
    Everything is computed and logged regardless; this governs only what the
    searcher can see, because a visible diagnostic is part of the treatment. Each
    arm of an agent experiment pins its view in the pre-registration.

    This is the only moment the design is still changeable, so it is the only
    moment an INADMISSIBLE verdict is useful: it is returned *before* any
    evaluation, naming the largest class size that would clear the power floor.

    Takes a configured `Sandbox`. The step 0 contract also offered a bare
    (T, K) base-return matrix; that is not implementable against the real
    Sandbox, whose `evaluate` needs the full (T, M, K) asset panel to compute
    `x_in @ weights` across assets, and a (T, K) matrix of per-feature returns
    cannot reconstruct it. Build the Sandbox, then open a watch on it.

    Pass the class to the Sandbox as well (`Sandbox(..., spec_class=cls)`) so
    membership is enforced at `evaluate` and `spec_class_source` records
    "sandbox" -- fixed before the search by construction, which is the tier's
    premise. `open` refuses a Sandbox carrying a different class."""
    ladder = spec_class if isinstance(spec_class, ClassLadder) else None
    if ladder is not None:
        if promotion not in PROMOTION_RULES:
            raise ValueError(f"promotion must be one of {PROMOTION_RULES}, got {promotion!r}")
        # The bar is the union's, and so is everything the transcript records: a
        # ladder name would not round-trip through garden.spec_class.parse, and
        # the union is what the declaration means for inference anyway.
        spec_class = ladder.union
    explicit = isinstance(spec_class, ExplicitClass)
    if not explicit and not isinstance(spec_class, SubsetClass):
        raise ValueError(
            f"watch takes a SubsetClass, a ClassLadder of them, or an ExplicitClass supplied "
            f"with class_returns; got {type(spec_class).__name__}."
        )
    if explicit:
        if ladder is not None:
            raise ValueError("a ClassLadder of explicit classes is not supported")
        if class_returns is None or class_ids is None:
            raise ValueError(
                "an ExplicitClass is priced from the streams themselves, so open() needs "
                "class_returns (T, M) and class_ids (M,): the return stream and id of every "
                "specification the search could produce. Assembling the class after seeing "
                "results is itself snooping, which is why it is declared here."
            )
        class_returns = np.asarray(class_returns, dtype=float)
        class_ids = tuple(str(c) for c in class_ids)
        if class_returns.ndim != 2 or class_returns.shape[1] != len(class_ids):
            raise ValueError(
                f"class_returns must be (T, M) with one id per column; got "
                f"{class_returns.shape} against {len(class_ids)} ids")
        if len(set(class_ids)) != len(class_ids):
            raise ValueError("class_ids must be unique: membership is matched by id")
        if not np.isfinite(class_returns).all():
            raise ValueError("class_returns contain NaN or inf")
        if spec_class.n_members is not None and spec_class.n_members != len(class_ids):
            raise ValueError(
                f"the class declares {spec_class.n_members} members but {len(class_ids)} "
                f"streams were supplied")
    elif class_returns is not None or class_ids is not None:
        raise ValueError("class_returns/class_ids are only meaningful for an ExplicitClass")

    enforced = getattr(sandbox, "spec_class", None)
    if enforced is not None and explicit:
        raise ValueError(
            "the sandbox enforces a weight-based class, which cannot also be an explicit "
            "class; open the sandbox without spec_class and let watch refuse by id")
    if enforced is not None and enforced != spec_class:
        raise ValueError(
            f"the sandbox enforces {enforced.name}, not {spec_class.name}"
            + (" (a ladder's sandbox must enforce the union)" if ladder is not None else "")
        )
    if isinstance(agent_view, str):
        if agent_view not in AGENT_VIEWS:
            raise ValueError(f"unknown agent_view {agent_view!r}; presets: {', '.join(AGENT_VIEWS)}")
        agent_view = AGENT_VIEWS[agent_view]

    base = sandbox.base_feature_columns()            # (T, K), adds nothing to the transcript
    T, K = base.shape
    ppy = sandbox.periods_per_year
    ann = np.sqrt(ppy)
    if explicit:
        if class_returns.shape[0] != T:
            raise ValueError(
                f"class_returns has {class_returns.shape[0]} periods, the sandbox {T}; "
                "the bar and the search must be priced on the same sample")
        class_size = len(class_ids)
        # The ordinary Reality Check, run directly on the supplied streams. This
        # is the same call `garden.audit` makes for an explicit class, with the
        # same B, block length, annualization and seed, which is what makes the
        # bar priced here and the bar priced at submit the same number.
        res = engine_null_max(class_returns, B=B, block_length=block_length,
                              annualization=ann, seed=seed)
        bar, L = res.M_b, res.block_length
        floor_binds, cap_binds = res.floor_binds, res.cap_binds
    else:
        class_size = spec_class.size(K)
        bar, L, floor_binds, cap_binds = full_class_null_max(
            base, spec_class, B=B, block_length=block_length, annualization=ann, seed=seed)
    c = critical_value(bar, alpha)
    # Power MUST be measured against the bar just priced, not against an
    # analytic independent-max critical value. Using the latter would make the
    # INADMISSIBLE decision here disagree with realized power everywhere except
    # rho = 0, since correlated class members lower the bootstrap bar. The only
    # analytic part is the Sharpe sampling law at T (Lo 2002); the threshold it
    # is compared against is the priced one, and it is the same `c` that
    # `evaluate` uses for `cleared`.
    power = analytic_power(reference_sharpe, c, T, ppy)

    admissible = None
    reasons = []
    if power >= power_floor:
        status = "OK"
        reasons.append(
            f"Class {spec_class.name} holds {class_size:,} specifications. Power for a single "
            f"pre-specified strategy at Sharpe {reference_sharpe:.2f} is {power:.1%}, above the "
            f"{power_floor:.0%} floor. The bar is fixed from now on: nothing evaluated inside the "
            f"class moves it."
        )
    else:
        status = "INADMISSIBLE"
        admissible = largest_admissible_class_size(
            T, ppy, reference_sharpe, alpha, power_floor, ceiling=class_size)
        reasons.append(
            f"Class {spec_class.name} holds {class_size:,} specifications, leaving {power:.1%} power "
            f"at Sharpe {reference_sharpe:.2f}, below the {power_floor:.0%} floor. A search this wide "
            f"could not certify an edge even if it found one."
        )
        reasons.append(
            f"At most {admissible:,} specifications would clear the floor on {T} periods."
            if admissible is not None else
            f"No class size clears the floor on {T} periods, not even a single pre-specified "
            f"specification. Lengthen the sample or raise the reference Sharpe."
        )
        reasons.append("Returned before any evaluation, while the design can still be changed.")
        reasons.append(
            "That size assumes independent specifications and is deliberately conservative: "
            "correlated members act as fewer, which lowers the class bar and raises power, so a "
            "highly correlated class can safely be wider than the number above and its realized "
            "power will come in higher than this estimate."
        )
    reasons.append(
        f"Power is for a single pre-specified strategy, not for the search (SCOPE.md, The cost of breadth). It is "
        f"measured against the bootstrap critical value priced over this class ({c:.3f}), the same "
        f"one `cleared` uses, so it already reflects however correlated the class turned out to be."
    )

    state = WatchState(
        status=status, critical_value=c, bar=bar, power_at_reference=power,
        class_name=spec_class.name, class_size=class_size, n_features=K, n_periods=T,
        periods_per_year=ppy, alpha=alpha, reference_sharpe=reference_sharpe,
        power_floor=power_floor, block_length=L, B=B,
        variance_floor_binds=floor_binds, sharpe_cap_binds=cap_binds,
        reasons=reasons, admissible_class_size=admissible,
        ladder=([{"name": lv.name, "size": lv.size(K)} for lv in ladder.levels]
                if ladder is not None else None),
        promotion=promotion if ladder is not None else None,
    )
    # Unannualized, matching searchers.dose_response.normalized_rank's own call.
    # Rank is scale-invariant either way; matching exactly is what lets the
    # equivalence test in tests/test_watch.py mean something.
    return Watch(sandbox, state, seed=seed, agent_view=agent_view,
                 base_sharpe=sharpe(base, axis=0),
                 ladder=ladder, promotion=promotion if ladder is not None else None,
                 declared=spec_class,
                 class_returns=class_returns if explicit else None,
                 class_ids=class_ids if explicit else None)
