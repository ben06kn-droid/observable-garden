"""Certification: pricing a logged search against the null 7.1 selected.

**The certifying null is trigger replay** (`fixed-sequence-replay`, read
2026-09-24): the logged search re-executed on each resample with its declared
triggers re-evaluated at every step. Its rejection rate came in at or below
nominal for all six registered searchers, 3.45-4.70% at a nominal 5% and
0.35-0.90% at 1%, so it is valid to certify with; the rates sit *under* nominal
as P2 predicts for a searcher submitting less than its class maximum, and **no
exactness is claimed**.

The other two nulls are computed and reported beside it:

- **fixed-sequence replay** is the bracket's lower end. 7.1's rule 2 licenses
  that: freezing the meta decisions is liberal (+0.0120 at alpha = 0.05 for the
  searchers that stop at a bar), so its p-value is a lower bound on the
  certifying one. This is the field `prereg/bracketed-verdicts.md` left for part
  two, and it is filled in here.
- **policy replay** is exact for a scripted policy and has no agent counterpart;
  it is reported when available as the reference the other two are read against.

**The fill.** Where a replicate runs past the realized length, the declared
triggers still decide, and a step they let continue takes the best one-step
content move over extend, swap and flip. 7.1 measured that move's direction, and
`FILL_NOTE` states it on **every verdict whose replicates used it**.

The upper end of the bracket stays the declared-class p-value and is not
computed here. 7.3 reported and did not license local-max pricing: its scripted half
did not test the conjecture and its agent cell deferred the fidelity check. The
declared-class tier is the fallback, and the certifying tier wherever the class is
enumerable (ROADMAP, the tier rule of 2026-09-30).
"""
from __future__ import annotations

import numpy as np

from estimator.bootstrap import select_block_length, stationary_bootstrap_indices
from estimator.trigger_replay import ReplayNulls
from quixote.confidence import confidence
from quixote.confidence import render as render_confidence
from quixote.pricing import DEFAULT as NO_PRICING
from quixote.pricing import PricingOptions, steps_to_price
from quixote.replay import (LoggedPolicy, commitment_check,
                            integrity_check)
from quixote.verdict import DEPENDS_ON_JUDGMENT, QuixoteVerdict

CERTIFYING_NULL = "trigger replay (fixed-sequence-replay, read 2026-09-24)"

FILL_NOTE = (
    "This verdict's null used the fill: on {engaged:,} of {B:,} replicates "
    "({share:.1%}) the search ran past its realized length and took the best "
    "one-step content move, with the declared triggers still evaluated. 7.1 "
    "measured that move's direction against a width-2 beam: LIBERAL, positive on "
    "1,506 of 1,507 draws where the two differ. It moved no verdict there "
    "(type-I 0.0440 under both nulls at alpha = 0.05, no discordant draws, "
    "McNemar p = 1.0000), so strengthening the fill is optional rather than "
    "required. Continuations stronger than a width-2 beam are untested.")

# A progress callback, where one is given, is called as progress(stage, done, total) at most
# this often (in replicates) and once at the end. It only observes: no draw or result changes.
PROGRESS_EVERY = 200


def _report(progress, stage: str, done: int, total: int) -> None:
    if progress is not None and (done % PROGRESS_EVERY == 0 or done == total):
        progress(stage, done, total)


NO_FILL_NOTE = ("The fill was never used: no replicate ran past the realized "
                "length, so nulls 2 and 3 can only differ by chance in the "
                "bootstrap, not by the fill's choice.")


def _path(trace, score_fn) -> dict:
    """One replicate of the certifying null, as data: each step's action and the rule held after
    it, scored on that replicate (the scores the null itself used)."""
    steps = []
    for act, sup in zip(trace.moves, trace.supports):
        steps.append({"action": str(act), "support": [[int(k), float(s)] for k, s in sup],
                      "sharpe": None if score_fn is None else float(score_fn(sup, "sharpe"))})
    return {"score": float(trace.score), "filled": bool(trace.filled), "steps": steps}


def three_nulls(log, spec_class, base: np.ndarray, annualization: float = 1.0,
                B: int = 10_000, block_length: int | None = None,
                seed: int | None = None,
                pricing: PricingOptions = NO_PRICING,
                table=None, progress=None, replicate_paths: int = 0,
                paths_out: list | None = None) -> tuple[ReplayNulls, np.ndarray]:
    """Nulls 1-3 for a logged search, plus the per-replicate engagement flag.

    The resampling is `estimator.trigger_replay.replay_nulls`', replicate for
    replicate: the realized search on the columns as they are, replicates from
    the demeaned columns by the stationary bootstrap, one RNG seeded by `seed`.
    `tests/test_quixote_certify.py` holds the two equal. It is repeated here only
    because `replay_nulls` returns scores and this needs the engagement flag too.
    """
    priced, _ = steps_to_price(log, pricing)
    policy = LoggedPolicy(log, spec_class, locally_priced=priced)
    base = np.asarray(base, dtype=float)
    T = base.shape[0]
    S0 = base - base.mean(axis=0, keepdims=True)
    L = int(select_block_length(S0)) if block_length is None else int(block_length)
    rng = np.random.default_rng(seed)

    # With a class table the resampling is over ROWS of the table, and every
    # score - realized and replicate alike - is a lookup into the stored
    # net-of-cost streams (`environments/class_table.py`). Without one the
    # replicate is a resampled base matrix, which is the simulated-panel path and
    # is unchanged.
    def scorers(rows):
        return None if table is None else table.scorer(rows, demeaned=True)

    realized = policy.trace(base, annualization,
                            score_fn=None if table is None else table.scorer(None))
    acts, n = realized.actions(), realized.n_moves
    n1, n2, n3 = np.empty(B), np.empty(B), np.empty(B)
    engaged = np.zeros(B, dtype=bool)
    handed = np.zeros(B, dtype=bool)
    for b in range(B):
        idx = stationary_bootstrap_indices(T, L, rng)
        R = S0[idx, :]
        sf = scorers(idx)
        n1[b] = policy.trace(R, annualization, frozen=acts, score_fn=sf).score
        t2 = policy.trace(R, annualization, meta_steps=n, score_fn=sf)
        n2[b], engaged[b] = t2.score, bool(t2.filled)
        handed[b] = t2.handover_step is not None
        n3[b] = policy.trace(R, annualization, score_fn=sf).score
        if paths_out is not None and b < replicate_paths:
            paths_out.append(_path(t2, sf))
        _report(progress, "replay", b + 1, B)
    return ReplayNulls(fixed_sequence=n1, trigger=n2, policy=n3, block_length=L, B=B,
                       realized_score=realized.score,
                       realized_actions=tuple(acts),
                       handover_replicates=int(handed.sum())), engaged


def _submitted_score(log) -> float | None:
    """The best score the session itself reached, which is what it submitted."""
    scores = [r.score_after for r in log.records if r.score_after is not None]
    return max(scores) if scores else None


def _declares_stop_rule(log) -> bool:
    """Does the declaration contain a stop action at all? A procedure without one
    has no end of its own: its replay runs to the declared budget under the fill."""
    return any((d.get("action") if isinstance(d, dict) else None) == "stop"
               for d in (getattr(log, "declared_trigger_records", ()) or ()))


NO_STOP_RULE_NOTE = (
    "This declaration contains NO STOP RULE, so the procedure has no end of its "
    "own: its replay runs to the declared budget under the fill, on the realized "
    "data and on every replicate alike. The verdict therefore attaches to the "
    "SUBMITTED specification (p_certifying) and the procedure's own statistic is "
    "reported beside it (p_procedure); the two are different searches here, and on "
    "7.3 scripted's faithful arm they differed by 0.0903 in score and by 0.0425 "
    "against 0.0085 in rejection rate.")


def certify(log, spec_class, base: np.ndarray, annualization: float = 1.0,
            alpha: float = 0.05, B: int = 10_000, block_length: int | None = None,
            seed: int | None = None, p_declared_class: float | None = None,
            pricing: PricingOptions = NO_PRICING, table=None, progress=None,
            replicate_paths: int = 0, paths_out: list | None = None) -> QuixoteVerdict:
    """Price a logged search against the trigger-replay null.

    A run whose replay disagrees with itself on the un-resampled data is
    **flagged and not priced** (the identity guard), because there is no
    defensible way to price a search whose own replay is not that search.
    """
    score_fn = None if table is None else table.scorer(None)

    # INTEGRITY FIRST, on every run, changes or not. It holds the realized meta
    # decisions fixed and re-executes the logged content moves, so no rule of the
    # agent's is involved: it asks only whether the basis and the engine
    # reproduce what the harness recorded. Until 2026-09-25 the trigger-change
    # branch below priced `three_nulls` with no such check, so a basis or engine
    # defect was invisible on any run with a change.
    integrity = integrity_check(log, spec_class, base, annualization, score_fn=score_fn)
    if not integrity.agrees:
        return QuixoteVerdict(
            status="UNDECIDABLE", alpha=alpha,
            n_moves=log.n_moves, n_candidates=log.total_candidates(),
            contradicted_picks=len(log.contradicted_picks()),
            reasons=[integrity.reason(),
                     "Not priced, and no other branch is taken: a run whose own log "
                     "cannot be re-executed is not a run any null can price, whatever "
                     "else it logged."])

    guard = commitment_check(log, spec_class, base, annualization, score_fn=score_fn)
    changes = list(getattr(log, "trigger_changes", ()) or ())
    if not guard.agrees:
        # A run that CHANGED a declared trigger is expected to diverge here, and
        # that is what the bracket is for rather than a reason to refuse. The
        # pre-change rule is what replays (`quixote/session.change_trigger`), so
        # the search after the change is a decision the null cannot price: the
        # verdict is DEPENDS_ON_JUDGMENT, naming the change, with the
        # fixed-sequence null reported as the bracket's liberal end.
        if changes:
            nulls, _ = three_nulls(log, spec_class, base, annualization, B,
                                   block_length, seed, pricing=pricing, table=table,
                                   progress=progress)
            first = changes[0]
            v = QuixoteVerdict(
                status=DEPENDS_ON_JUDGMENT, alpha=alpha,
                p_frozen=nulls.p_value("fixed_sequence"),
                p_upper=p_declared_class,
                n_moves=log.n_moves, n_candidates=log.total_candidates(),
                realized_score=float(nulls.realized_score),
                unreplayable_decisions=tuple(
                    r.move.kind for r in log.records
                    if r.step >= first["at_step"] or not r.replayable),
                contradicted_picks=len(log.contradicted_picks()),
                responsible_decision=(
                    f"change_trigger at step {first['at_step']} to "
                    f"{first['trigger']['kind']}({first['trigger']['param']:g}) -> "
                    f"{first['trigger'].get('action', 'stop')}"
                    + (f": {first['reason']}" if first.get("reason") else "")),
                bracket_source=("lower end: fixed-sequence replay under the rule the "
                                "search committed to; upper end: "
                                + ("the declared-class p-value" if p_declared_class
                                   is not None else "not computed")))
            v.reasons += [
                integrity.reason(),
                guard.reason(),
                f"{len(changes)} declared trigger change(s) are logged, so the replay "
                "under the committed rule is EXPECTED to diverge from the realized "
                "search. That divergence is priced in the bracket rather than "
                "refused: the run is DEPENDS_ON_JUDGMENT and names the change.",
                "The change is a decision taken after seeing results. Nothing here "
                "says it was a bad one; it says the certifying null cannot price it."]
            return v
        return QuixoteVerdict(
            status="UNDECIDABLE", alpha=alpha,
            n_moves=log.n_moves, n_candidates=log.total_candidates(),
            reasons=[guard.reason(),
                     "Not priced: the certifying null would be pricing a search that did "
                     "not run."])

    priced, pricing_reasons = steps_to_price(log, pricing)
    nulls, engaged = three_nulls(log, spec_class, base, annualization, B, block_length,
                                 seed, pricing=pricing, table=table, progress=progress,
                                 replicate_paths=replicate_paths, paths_out=paths_out)
    n_eng = int(engaged.sum())
    # The PROCEDURE's statistic: what the declared procedure reaches on the
    # realized data, which is what the replay produces.
    p_procedure = nulls.p_value("trigger")
    # The SUBMITTED statistic: the best the session itself reached. CERTIFIED
    # attaches to this one, priced against the SAME null — one extra comparison,
    # no extra bootstrap. The two coincide whenever the search ended under its own
    # declared rule, and diverge when it did not: a procedure with no stop rule
    # replays to its budget under the fill, so it reaches a score the session never
    # submitted. Certifying the procedure's score in that case would certify a
    # search the searcher did not perform.
    submitted = _submitted_score(log)
    p_submitted = (p_procedure if submitted is None
                   else nulls.p_value("trigger", sr=submitted))
    has_stop = _declares_stop_rule(log)

    v = QuixoteVerdict(
        status="CERTIFIED" if p_submitted < alpha else "FAIL",
        alpha=alpha,
        p_frozen=nulls.p_value("fixed_sequence"),
        p_upper=p_declared_class,
        bracket_source=("lower end: fixed-sequence replay, licensed by 7.1's rule 2 "
                        "(freezing is liberal, +0.0120 at alpha = 0.05); upper end: "
                        + ("the declared-class p-value" if p_declared_class is not None
                           else "not computed; local-max pricing is unlicensed "
                                "(7.3 reported without testing it)")),
        n_moves=log.n_moves,
        n_candidates=log.total_candidates(),
        unreplayable_decisions=tuple(r.move.kind for r in log.unreplayable()),
        certifying_null=CERTIFYING_NULL,
        p_certifying=p_submitted,
        p_procedure=p_procedure,
        submitted_score=(None if submitted is None else float(submitted)),
        declares_stop_rule=has_stop,
        p_policy=nulls.p_value("policy"),
        realized_score=float(nulls.realized_score),
        fill_engaged=n_eng,
        handover_replicates=nulls.handover_replicates,
        fill_replicates=B,
        contradicted_picks=len(log.contradicted_picks()),
        locally_priced_steps=tuple(sorted(priced)),
        pricing_licensed=False if priced else None,
        confidence_replay=confidence(
            float(nulls.realized_score if submitted is None else submitted),
            nulls.trigger, ppy=float(annualization) ** 2, tier="trigger replay (audit)"),
    )
    v.reasons.append(integrity.reason())
    v.reasons.append(render_confidence(v.confidence_replay,
                                       certified=v.status == "CERTIFIED"))
    if not has_stop:
        v.reasons.append(NO_STOP_RULE_NOTE)
    elif submitted is not None and p_submitted != p_procedure:
        v.reasons.append(
            "The submitted and procedure statistics differ although a stop rule is "
            "declared, which is unexpected: a search ending under its own rule "
            "submits what its procedure reaches. Reported rather than reconciled.")
    if changes:
        v.reasons.append(
            f"{len(changes)} declared trigger change(s) are logged, and the commitment "
            "check PASSES: the rule the search committed to reproduces the search that "
            "ran, so the changes NEVER BOUND. Nothing is bracketed and no move is "
            "recorded unreplayable for them. A change is priced when it costs "
            "something, and this one did not.")
    v.reasons.append(
        f"The verdict attaches to the SUBMITTED specification: p = {p_submitted:.4f} "
        f"against alpha = {alpha}, priced against {CERTIFYING_NULL} — the declared "
        f"procedure's null. Beside it, the PROCEDURE's own statistic prices at "
        f"p = {p_procedure:.4f} on the same replicates. "
        "7.1 measured this null at or below nominal for all six registered searchers "
        "(3.45-4.70% at a nominal 5%); the rates sit under nominal as P2 predicts, and no "
        "exactness is claimed.")
    v.reasons.append(FILL_NOTE.format(engaged=n_eng, B=B, share=n_eng / B) if n_eng
                     else NO_FILL_NOTE)
    v.reasons.append(
        f"Reported beside it: fixed-sequence replay p = {v.p_frozen:.4f} (the bracket's "
        f"lower end) and policy replay p = {v.p_policy:.4f} (exact for a scripted policy, "
        "with no agent counterpart).")
    v.reasons.extend(pricing_reasons)
    v.reasons.append(guard.reason())
    return v
